package dao;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.junit.Test;

import bean.BookOrder;
import utils.HibernateUtils;

public class OrderOperationDao {

	public int addOrder(BookOrder bookorder) {
		Session session = HibernateUtils.openSession();
		Transaction tx = session.beginTransaction();
		BookOrder findBookOrder = findBookOrder(bookorder.getUsername());
		if(findBookOrder == null) {
			session.save(bookorder);
			tx.commit();
			return 1;
		}else {
			return 0;
		}
		
	}
	
	public BookOrder findBookOrder(String username) {
		Session session = HibernateUtils.openSession();
		Transaction tx = session.beginTransaction();
		BookOrder bookOrder = session.get(BookOrder.class, username);
		tx.commit();
		session.close();
		return bookOrder;
	}

}
