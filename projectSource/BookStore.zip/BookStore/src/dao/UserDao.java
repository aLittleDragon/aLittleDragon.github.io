package dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import bean.User;
import utils.HibernateUtils;

public class UserDao {

	public User findUser(String username) {
		Session session = HibernateUtils.openSession();
		Transaction tx = session.beginTransaction();
		User user = session.get(User.class, username);
		tx.commit();
		return user;
	}

}
