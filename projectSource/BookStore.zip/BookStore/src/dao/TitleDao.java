package dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.junit.Test;

import bean.Title;
import utils.HibernateUtils;

public class TitleDao {
	
	public List<Title> getAllTitles(){
		Session session = HibernateUtils.openSession();
		Transaction tx = session.beginTransaction();
		//ȫ�� ����sql���ı���ʽ from �־û���
		Query qr = session.createQuery("from Title");
		List<Title> titleList = qr.list();
		/*
		 * for(Title title: list) { System.out.println(title); }
		 */
		tx.commit();
		session.close();
		return titleList;
	}

	public Title findTitleByIsbn(String isbn) {
		Session session = HibernateUtils.openSession();
		Transaction tx = session.beginTransaction();
		Title title = session.get(Title.class, Long.parseUnsignedLong(isbn));
		return title;
	}

}
