package service;

import bean.BookOrder;
import dao.OrderOperationDao;

public class OrderOperationService {

	public int addOrder(BookOrder bookorder) {
		OrderOperationDao dao = new OrderOperationDao();
		return dao.addOrder(bookorder);
	}
}
