package service;

import bean.User;
import dao.UserDao;

public class UserService {

	public User findUser(User user) {
		System.out.println(user);
		UserDao dao = new UserDao();
		User user2 = dao.findUser(user.getUsername());
		return user2;
	}
}
