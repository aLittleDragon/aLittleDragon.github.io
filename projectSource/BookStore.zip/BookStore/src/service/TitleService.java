package service;

import java.util.List;

import bean.Title;
import dao.TitleDao;

public class TitleService {

	public List<Title> getAllTitles() {
		TitleDao dao = new TitleDao();
		List titleList = dao.getAllTitles();
		return titleList;
	}

	public Title findTitleByIsbn(String isbn) {
		TitleDao dao = new TitleDao();
		Title title = dao.findTitleByIsbn(isbn);
		return title;
	}
}
