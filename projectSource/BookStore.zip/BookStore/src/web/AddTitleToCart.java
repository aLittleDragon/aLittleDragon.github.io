package web;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.CartItem;
import bean.Title;

/**
 * Servlet implementation class AddTitleToCart
 */
@WebServlet("/AddTitleToCart")
public class AddTitleToCart extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddTitleToCart() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		RequestDispatcher dispatcher = null;
		if(session == null) {
			dispatcher = request.getRequestDispatcher("/viewBook.jsp");
			dispatcher.forward(request, response);
		}
		Map<Long,CartItem> cart = (Map<Long, CartItem>) session.getAttribute("cart");
		Title title = (Title)session.getAttribute("title");
		if(cart == null) {
			cart = new HashMap<Long, CartItem>();
			session.setAttribute("cart", cart);
		}
		CartItem cartItem = (CartItem)cart.get(title.getIsbn());
		if(cartItem != null) {
			cartItem.setQuantity(cartItem.getQuantity() + 1);
		}else {
			CartItem cartItem1 = new CartItem();
			cartItem1.setTitle(title);
			cartItem1.setQuantity(1);
			cart.put(title.getIsbn(), cartItem1);
		}
		dispatcher = request.getRequestDispatcher("/viewCart.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
