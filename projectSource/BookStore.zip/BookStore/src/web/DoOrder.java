package web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.BookOrder;
import service.OrderOperationService;

/**
 * Servlet implementation class DoOrder
 */
@WebServlet("/DoOrder")
public class DoOrder extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DoOrder() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		BookOrder bookorderbean = new BookOrder();
		request.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession();
		bookorderbean.setUsername(request.getParameter("username"));
		bookorderbean.setZipcode(request.getParameter("zipcode"));
		bookorderbean.setPhone(request.getParameter("phone"));
		bookorderbean.setCreditcart(request.getParameter("creditcart"));
		bookorderbean.setTotal(((Double)session.getAttribute("total")).doubleValue());
		session.setAttribute("order", bookorderbean);
		OrderOperationService service = new OrderOperationService();
		int ok = service.addOrder(bookorderbean);
		if(ok == 0)
			System.out.println("������¼����ʧ��");
		System.out.println("������¼���ӳɹ�");
		request.getRequestDispatcher("bye.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
