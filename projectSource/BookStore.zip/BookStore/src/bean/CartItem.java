package bean;

public class CartItem {

	private Title title;
	private int quantity;

	public Title getTitle() {
		return title;
	}

	public void setTitle(Title title) {
		this.title = title;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "CartItem [title=" + title + ", quantity=" + quantity + "]";
	}

}
