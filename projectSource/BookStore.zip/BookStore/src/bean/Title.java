package bean;

public class Title {

	private Long isbn;
	private String title;
	private String copyright;
	private String imageFile;
	private Integer editionNumber;
	private String publisherId;
	private Float price;

	public Title() {
		
	}
	
	public Title(Long isbn, String title, String copyright, String imageFile, Integer editionNumber,
			String publisherId, Float price) {
		super();
		this.isbn = isbn;
		this.title = title;
		this.copyright = copyright;
		this.imageFile = imageFile;
		this.editionNumber = editionNumber;
		this.publisherId = publisherId;
		this.price = price;
	}

	public Long getIsbn() {
		return isbn;
	}

	public void setIsbn(Long isbn) {
		this.isbn = isbn;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCopyright() {
		return copyright;
	}

	public void setCopyright(String copyright) {
		this.copyright = copyright;
	}

	public String getImageFile() {
		return imageFile;
	}

	public void setImageFile(String imageFile) {
		this.imageFile = imageFile;
	}

	public Integer getEditionNumber() {
		return editionNumber;
	}

	public void setEditionNumber(Integer editionNumber) {
		this.editionNumber = editionNumber;
	}

	public String getPublisherId() {
		return publisherId;
	}

	public void setPublisherId(String publisherId) {
		this.publisherId = publisherId;
	}

	public Float getPrice() {
		return price;
	}

	public void setPrice(Float price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Title [isbn=" + isbn + ", title=" + title + ", copyright=" + copyright + ", imageFile=" + imageFile
				+ ", editionNumber=" + editionNumber + ", publisherId=" + publisherId + ", price=" + price + "]";
	}

}
