package bean;

public class BookOrder {

	private String username;
	private String zipcode;
	private String phone;
	private String creditcart;
	private Double total;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getCreditcart() {
		return creditcart;
	}

	public void setCreditcart(String creditcart) {
		this.creditcart = creditcart;
	}

	public Double getTotal() {
		return total;
	}

	public void setTotal(Double total) {
		this.total = total;
	}

	@Override
	public String toString() {
		return "BookOrder [username=" + username + ", zipcode=" + zipcode + ", phone=" + phone + ", creditcart="
				+ creditcart + ", total=" + total + "]";
	}

}
